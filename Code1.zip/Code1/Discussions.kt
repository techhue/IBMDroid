
Installing Kotlin Compiler
____________________________________________________
	- Download kotlin-compiler-1.3.61.zip
	- Unzip In IBMDroid Directory

Running Kotlin Compiler
____________________________________________________
	cd kotlinc/bin
	./kotlinc

Configure PATH Variable
____________________________________________________
	Add Following Path in PATH Variable
		YOUR_DIRECTORY\Documents\IBMDroid\kotlinc\bin
	
	Invoke Kotlin Compiler
		Now You Can Invoke Following Command From Any Path
		
		kotlinc

Install Java SDK 1.8
____________________________________________________
	https://www.oracle.com/java/technologies/javase/javase-jdk8-downloads.html

	Java JDK 1.8 - For Windows 64 Bit Architecture
	________________________________________________
	Download : jdk-8u241-windows-x64.exe
		Size : 210.92 MB	
	Install  : jdk-8u241-windows-x64.exe

DAY 1
____________________________________________________
	Reading Assignments
	________________________________________________
		Data Type and Control Structures Chapters

		Programming In C By Kernigham and Dennis Ritchie
		2nd Edition

	Reasoning Assignments
	________________________________________________
		Is it possible to have variable
			Without Type as an Idea?

		Is it possible to have value 
			Without Type as an Idea?

		Which is Most Fundamental Value/Variable/Type
			Reason It!
DAY 2
____________________________________________________
	Reading Assignments
	________________________________________________
		Data Type and Control Structures Chapters

		Programming In C By Kernigham and Dennis Ritchie
		2nd Edition

	Reasoning Assignments
	________________________________________________
		Which is Most Fundamental Value/Variable/Type
			Reason It!
		
		Type and Variables Must Coexits Always!
			Reason It?

		Set Definition:
			Collection of Objects. 
			Order and Duplicates Doesn't Matters

			What is an Object?
			Why Order Doesn't Matters?
				What Is Far More Fundamental Order or Unordered?
				Reason It!
			Why Duplicates Doesn't Matters?

Data Type
____________________________________________________
	Type is { Operations, Range }
	
	Type Analysis
		Deeper Type Analysis
			Depth Wise Type Analysis

	Type Inferencing
		Explicit In C/C++
		Implicit In Kotlin
		
	Type Binding
		Compile Time
			C/C++/Java/Kotlin
		Run Time
			Python/Ruby/javase

	Type Safety


Thinking Exercise
____________________________________________________
