
#include <stdio.h>

void playWithConditionals() {
	int x = -10;
	int y = 0;
	int z = 0;
	
	return if (x) y++; else y--;

	printf("\nY Value: %d", y);

	z = 10 + ((x)? y++ : y--);
	printf("\nY Value: %d", y);
	printf("\nZ Value: %d", z);
	
	y = (x)? 200 : 300;
	printf("\nY Value: %d", y);
}

int main() {
	playWithConditionals();
}
