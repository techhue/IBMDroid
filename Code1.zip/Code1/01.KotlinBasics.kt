package learnKotlin
/*
kotlinc 01.KotlinBasics.kt -include-runtime -d basics.jar
java -jar basics.jar
*/

import java.util.Random
import java.util.TreeMap

fun helloWorld() {
	val greeting = "Welcome IBMers!"
	println("Hello World! " + greeting);
}

fun max(a: Int, b: Int): Int {
	if (a > b) {
		return a
	} else {
		return b
	}
}

fun maxNew(a: Int, b: Int): Int {
	return if (a > b) {
		a
	} else {
		b
	}
}

//error: type mismatch: inferred type is Int but Unit was expected
fun maxNew1(a: Int, b: Int) {
	return if (a > b) {
		// a
		// print(a)
	} else {
		// b
		// print(b)
	}
}

// Getter and Setters Generated For Every Property
// Will Generate Default Constructor
//		Memberwise Initialiser : Will Initialise All Properties

// User Defined Type

class Person(val name: String, val isMarried: Boolean)

fun playWithPerson() {
	val person = Person("Modi", false)
	println(person.name)
	println(person.isMarried)

	// val person1 = Person()
	// println(person1.name)
	// println(person1.isMarried)

	// val person2 = Person("Ding Dong")
	// val person3 = Person(isMarried: true)
}

class Person1(
	val name: String = "", 
	val isMarried: Boolean = false
)

fun playWithPerson1() {
	val person = Person1("Modi", false)
	println(person.name)
	println(person.isMarried)

	val person1 = Person1() // Person1("", false)
	println(person1.name)
	println(person1.isMarried)

	// val person2 = Person("Ding Dong")
	// val person3 = Person(isMarried: true)
}


// In Java and C++
// class Rectangle {
// 	val height: Int;
// 	val width: Int;
// 	//val isSquare: Boolean;

// 	Boolean isSquare() {
// 		if height == width {
// 			isSquare = true
// 		} else {
// 			isSquare = false
// 		}
// 		return isSquare
// 	}
// 	// //Computed Property
// 	// val isSquare: Boolean 
// 	// 	get() {
// 	// 		return height == width
// 	// 	}
// }

// Rectangle rect = new Rectangle(10, 20);
// rect.isSquare();

// What is Getter and Setters?
// In Rectangle
// 		height and width are Stored Properties
//		isSquare is a Computed Property

				//Stored Properties
class Rectangle(val height: Int, val width: Int) {
	//Computed Property
	val isSquare: Boolean 
		get() {
			return height == width
		}
}

fun playWithRectangle() {
	val rectangle = Rectangle(40, 20)
	println(rectangle.height)
	println(rectangle.width)
	println(rectangle.isSquare) // rectanlge.getIsSquare()
}

fun createRectangle(): Rectangle {
	val random = Random()
	return Rectangle(random.nextInt(), random.nextInt())
}

fun mutability() {
	// Immutable
	val something = "Ding Dong"
	println(something)
	//something = "Ting Tong"

	//Mutable
	var something1 = "Ding Dong"
	println(something1)
	something1 = "Ting Tong"
	println(something1)

	// something1 = 100
	// println(something1)
}

fun playWithTypes() {
	// Type Binding At Compile Time
	var something1 = "Ding Dong"
	println(something1)

	// something1 = 100
	// println(something1)

	val a = 10
	println(a)

	val bb: Int
	bb = 100
	println(bb)
}

// User Defined Types
enum class Color {
	RED, GREEN, BLUE, PINK	
}

fun playWithColors() {
	var c = Color.RED
	print(c)

	var something: Int = 10
	// c = something
	print(something)
}

// warning: the expression is unused
fun playWithColorsWhen() {
	var color = Color.RED
	var colorString: String //= "Unknown Color"
	when (color) {
		Color.RED 	-> colorString = "Red Color"
		Color.GREEN -> colorString = "Green Color"
		Color.BLUE	-> colorString = "Blue Color"
		Color.PINK 	-> colorString = "Pink Color"
	}
	// println(colorString)
	println(colorString)
	color = Color.GREEN
	// colorString = when (color) {
	val something = when (color) {
		Color.RED 	-> "Red Color"
		Color.GREEN -> "Green Color"
		// Color.BLUE	-> 500
		Color.BLUE	-> "Blue Color"
		Color.PINK 	-> "Pink Color"
	}
	println(something)
}

fun playWithColorsWhen(color: Color): String {
	return when (color) {
		Color.RED 	-> "Red Color"
		Color.GREEN -> "Green Color"
		Color.BLUE	-> "Blue Color"
		Color.PINK 	-> "Pink Color"
	}
}

//error: 'when' expression must be exhaustive, add necessary 'BLUE' branch or 'else' branch instead
fun playWithColorsWhen1(color: Color) = when (color) {
		Color.RED 	-> "Red Color"
		Color.GREEN -> "Green Color"
		Color.BLUE	-> "Blue Color"
		Color.PINK 	-> "Pink Color"
		// else 		-> "Unknown Color" 
}

fun getWarmth(color: Color) = when(color) {
	Color.RED, Color.PINK 	-> "Warm"
	Color.GREEN, Color.BLUE -> "Cold"
}

enum class Color1 {
	RED, GREEN, BLUE, PINK,
	YELLOW, VIOLET,
	UNKNOWN
}

// Pemature Optimisation Is Always Bad Idea
fun mixColors(c1: Color1, c2: Color1) = when( setOf(c1, c2) ) {
	setOf(Color1.RED, Color1.GREEN) -> Color1.YELLOW
	setOf(Color1.BLUE, Color1.RED) 	-> Color1.VIOLET
	// else -> "Unknown Color" 
	// else -> throw Exception("Unknown Color")

	// Best Design - Fundamental Law Closure Law/Property
	else -> Color1.UNKNOWN
}

fun playWithIfElse() {
	// val b: Int = 10
	val b: Boolean = true
	if (b) { // Boolean Type != Int Type
		println("Balleee Balleee...")
	} else {
		println("Helloooo....")
	}
}

// Optimise Code - BASED ON SOUND REASONING 
fun mixOptimized(c1: Color1, c2: Color1) = when {
	// setOf(Color1.RED, Color1.GREEN) 	-> Color1.YELLOW
	// setOf(Color1.BLUE, Color1.RED) 	-> Color1.VIOLET
	(c1 == Color1.RED && c2 == Color1.GREEN) ||
	(c2 == Color1.RED && c1 == Color1.GREEN) -> Color1.YELLOW

	(c1 == Color1.BLUE && c2 == Color1.RED) ||
	(c2 == Color1.BLUE && c1 == Color1.RED) -> Color1.VIOLET

	else -> Color1.UNKNOWN
}

fun fizzBuzz(value: Int) = when {
	value % 15 == 0 -> "FizzBuzz"
	value % 5  == 0 -> "Fizz"
	value % 3  == 0 ->  "Buzz"
	else -> " $value "
}

fun fizzBuzzThings() {
	//1..10 means [1, 10]
	//For-In Loop
	for (value in 1..10) {
		println(value)
		print(fizzBuzz(value))
	}

	for (value in 10 downTo 1 step 2) {
		println(value)
		print(fizzBuzz(value))
	}
}

fun iteratingMaps() {
	val binaryRepresentation = TreeMap<Char, String>()

	// Type Inferencing and Binding - Compile Time
	// Value Generation - Runtime
	//		Sequence -> Iterator
	//		Call Next On Iterator
	//			StopIteration
	
	for (c in 'A'..'F') {
		val binary = Integer.toBinaryString(c.toInt())
		binaryRepresentation[c] = binary
	}

	for ( (letter, binary) in binaryRepresentation) {
		println( " $letter Value: $binary")
	}
}

fun isLetter(c: Char) 	= c in 'a'..'z' || c in 'A'..'Z'
fun isNotDigit(c: Char) = c !in '0'..'9'

// Cyclomatic Complexity - Nestedness of Code
fun recorgnize(c: Char) = when(c) {
	in '0'..'9' -> "Digit"
	in 'a'..'z' -> "LowerCase"
	in 'A'..'Z' -> "UpperCase"
	else -> "Unknown Stuff"
}

fun main() {
	println("\nFunction : helloWorld")
	helloWorld()

	println("\nFunction : max")
	println(max(-100, 99))

	println("\nFunction : maxNew")
	println(maxNew(-100, 99))

	println("\nFunction : playWithPerson")
	playWithPerson()

	println("\nFunction : playWithPerson1")
	playWithPerson1()

	println("\nFunction : playWithRectangle")
	playWithRectangle()

	println("\nFunction : createRectangle")
	val rectangle = createRectangle()
	println(rectangle.height)
	println(rectangle.width)
	
	println("\nFunction : mutability")
	mutability()

	println("\nFunction : playWithTypes")
	playWithTypes()

	println("\nFunction : playWithColors")
	playWithColors()

	println("\nFunction : playWithColorsWhen")
	playWithColorsWhen()

	println("\nFunction : playWithColorsWhen")
	val color1 = Color.BLUE
	println(playWithColorsWhen(color1))

	println("\nFunction : playWithColorsWhen1")
	val color2 = Color.RED
	println(playWithColorsWhen1(color2))

	println("\nFunction : getWarmth")
	val color3 = Color.RED
	println(getWarmth(color3))

	println("\nFunction : mixColors")
	println( mixColors(Color1.RED, Color1.BLUE) )
	println( mixColors(Color1.BLUE, Color1.RED) )

	println( mixColors(Color1.RED, Color1.VIOLET) )
	
	println("\nFunction : playWithIfElse")
	playWithIfElse()

	println("\nFunction : mixOptimized")
	println( mixOptimized(Color1.RED, Color1.BLUE) )

	println("\nFunction : fizzBuzz")
	println(fizzBuzz(10))

	println("\nFunction : fizzBuzzThings")
	fizzBuzzThings()
	
	println("\nFunction : iteratingMaps")
	iteratingMaps()

	println("\nFunction : isLetter")
	println(isLetter('A'))
	println(isLetter('0'))
	println(isNotDigit('A'))
	println(isNotDigit('0'))
	
	println("\nFunction : recorgnize")
	println(recorgnize('A'))
	println(recorgnize('0'))
	println(recorgnize('a'))
	println(recorgnize('$'))

	// println("\nFunction : ")
}
