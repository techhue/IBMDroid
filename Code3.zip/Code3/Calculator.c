#include <stdio.h>

int sum(int a, int b) { return a + b; }
int sub(int a, int b) { return a - b; }
int mul(int a, int b) { return a * b; }

// Foundation 	: Abstract Type
// Direction	: Polymorphism
// Achieves 	: Loose Coupling
int calculator(int a, int b, int (*operation)(int, int)) {
	return operation(a, b);
}

// Tight Coupling
int calculator(int a, int b, int operation) {
	if (operation = SUM)
		return sum(a, b);
	else 
		return sum(a, b);
}

int main() {
	int a = 10, b = 20;
	int result = 0;

	result = calculator(a, b, sum);
	printf("\nCalculation Result: %d ", result);

	result = calculator(a, b, sub);
	printf("\nCalculation Result: %d ", result);
}
