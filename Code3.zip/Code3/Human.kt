package learnKotlin

// Theorem
interface Capability

// interface Superpower {
// 	fun fly()
// 	fun saveWorld()
// }

// interface Superpower: Capability {
// 	fun fly()
// 	fun saveWorld()
// }


interface Flying: Capability {
	fun fly()
	fun saveWorld()
}

interface SaveWorld: Capability {
	fun saveWorld()
}

interface Superpower: Flying, SaveWorld {
	fun fly()
	fun saveWorld()
}

interface Dancing: Capability {
	fun dance()
}

interface Singing: Capability {
	fun sing()
}

class Spiderman: Superpower, Dancing {
	override fun fly() 		 { println("Fly Like Spiderman!") }
	override fun saveWorld() { println("SaveWorld Like Spiderman!") }	
	override fun dance() 	 { println("Dance Like Spiderman!") }	
}

class Superman: Superpower {
	override fun fly() 		 { println("Fly Like Superman!") }
	override fun saveWorld() { println("SaveWorld Like Superman!") }	
}

class Heman : Superpower {
	override fun fly() 		 { println("Fly Like Heman!") }
	override fun saveWorld() { println("SaveWorld Like Heman!") }	
}

class HanumanJi : Superpower {
	override fun fly() 		 { println("Fly Like HanumanJi!") }
	override fun saveWorld() { println("SaveWorld Like HanumanJi!") }	
}

class Human {
	var power: Superpower? = null // New Thing
	// var dancing: Dancing? = null
	fun fly() 		 { power?.fly() } // super.fly() }
	fun saveWorld()  { power?.saveWorld() } // super.saveWorld }
	fun dance()		 { 
		val buddy = power as Dancing
		buddy.dance() 
	}
}

// Proof!
fun playWithHuman() {
	val h = Human()
	// h.power = Spiderman()
	// h.dancing =  Spiderman()
	h.fly()
	h.saveWorld()
	h.dance()

	h.power = Superman()
	h.fly()
	h.saveWorld()

	// h.power = Heman()
	// h.fly()
	// h.saveWorld()

	// h.power = HanumanJi()
	// h.fly()
	// h.saveWorld()
}

// class InterestingHuman {
// 	var capability: Capability ? = null 
	
// 	fun fly() 		 { 
// 		if // Type Check Then
// 		val buddy = capability as Superpower
// 		buddy.fly() 
// 	} 

// 	fun saveWorld()  { 
// 		val buddy = capability as Superpower
// 		buddy.saveWorld() 
// 	} 
	
// 	fun dance()		 { 
// 		val buddy = capability as Dancing
// 		buddy.dance() 
// 	}
// }

// Human
// 	fly like Superman
// 	dance like Spiderman
// 	saveWorld like HanumanJi

class SpecialHuman : Superpower, Dancing {
	// var capability: Capability ? = null
	var superman: Superman? 	= null
	var spiderman: Spiderman? 	= null
	var hanumanji: HanumanJi? 	= null
	
	fun fly() 		 { superman.fly()  }  // 	fly like Superman
	fun saveWorld()  { hanumanji.saveWorld()   }  // 	dance like Spiderman
	fun dance()		 { spiderman.dance()  }  // 	saveWorld like HanumanJi
}

class SpecialSpecialHuman : Spiderman, Superman, HanumanJi {
	// var capability: Capability ? = null
	// var superman: Superman? 	= null
	// var spiderman: Spiderman? 	= null
	// var hanumanji: HanumanJi? 	= null
	
	fun fly() 		 { super<Spiderman>.fly()  }  // 	fly like Superman
	fun saveWorld()  { super<Hanumanji>.saveWorld()   }  // 	dance like Spiderman
	fun dance()		 { super<Spiderman>.dance()  }  // 	saveWorld like HanumanJi
}


// Design Choices

// Design System Towards Abstract Types Rather Than Concrete Types
//		Design Towards Interface Rather Than Concrete Classes
//		Abstract Types/Interfaces
//			Promotes Design By Contract or Convetions!
			// It brings Trust in System!
			// 	Then System Robust!
// Design By Definition
// 		Types System is Theorem
//		Program is Proof!


fun main() {
	playWithHuman()
}

