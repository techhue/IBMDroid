package learnKotlin

interface Clickable {
	fun click() 	= println("Clickable Got Clicked!")
	fun showOff() 	= println("Clickable Showing Off!")
}

interface Focusable {
	fun setFocus() 	= println("Focusable Setting Focus!")
	fun showOff() 	= println("Focusable Showing Off!")
}

class Button: Clickable, Focusable {
	override fun click() = println("Button Got Clicked!")
	override fun showOff() {
		super<Clickable>.showOff()
		super<Focusable>.showOff()
	}
}

fun playWithButton() {
	var button = Button()
	button.click()
	button.setFocus()
	button.showOff()
}

open class View {
	open fun click() = println("View Got Clicked!")
	open fun showOff() 	= println("View Show Off!")
}

class Buttonn: View() {
	override fun click() = println("Button Got Clicked!")
	// fun click() = println("Button Got Clicked!")
	override fun showOff() 	= println("Buttonn Show Off!")
	fun magic() = println("Button's Magic!")
}

fun View.showingOff() = println("View Showing Off!")
fun Buttonn.showingOff() = println("Buttonn Showing Off!")

fun playWithButtonn() {
	var button: Buttonn = Buttonn()
	button.click()
	button.magic()
	button.showOff()
	button.showingOff()

	var view: View = Buttonn()
	view.click()
	view.showOff() 		//View showOff 4 	// Button showOff 5
	view.showingOff() 	//View showingOff 4	// Button showingOff 5
	// view.magic()
}

class Some {
	fun life() { 
		val something = Something()
		
		println("Funny Life!... Without Wife!") 
		something.haveFun()
	}

	// Nested Classes
	class Something {
		fun haveFun() { println("Funny In Fun Mood!...") }
	}
}

fun playWithSome() {
	val some = Some()
	some.life()
}

interface User {
    val email: String
    val nickname: String
        get() = email.substringBefore('@')
}

class User4(val name: String) {
    var address: String = "unspecified"
        set(value: String) {
            println("""
                Address was changed for $name:
                "$field" -> "$value".""".trimIndent())
            field = value
        }
}

fun playWithIntefacesAndClasses() {
	// Abstract Types
	// val clickable = Clickable()
	// val user = User()

	//
	val user4 = User4("Ram Singh")
	println("\n User Address: ${user4.address}")
	user4.address = "Ding Dong"
	println("\n User Address: ${user4.address}")
}


class Client1(val name: String, val postalCode: Int) {
    override fun toString() = "Client(name=$name, postalCode=$postalCode)"
}

fun stringRepresentationToString() {
    val client1 = Client1("Alice", 342562)
    println(client1)
}

//__________________________________________________

class Client2(val name: String, val postalCode: Int)
fun objectEqualityEquals() {
    val client1 = Client2("Alice", 342562)
    val client2 = Client2("Alice", 342562)
    //Reference Comparison : Default
    println(client1 == client2)
}
//________________________________________________________
class Client3(val name: String, val postalCode: Int) {
    override fun equals(other: Any?): Boolean {
        if (other == null || other !is Client3)
            return false
        return name == other.name &&
               postalCode == other.postalCode
    }
    override fun toString() = "Client(name=$name, postalCode=$postalCode)"
}
fun objectEqualityEquals1() {
    val processed = hashSetOf(Client3("Alice", 342562))
    println(processed.contains(Client3("Alice", 342562)))    
    val client1 = Client3("Alice", 342562)
    val client2 = Client3("Alice", 342562) 
    //Object Comparison
    println(client1 == client2) // println(client1.equals(client2))
}

//_________________________________________________________

// Generate
// 	equals Method
//	toString Method
data class Client4(val name: String, val postalCode: Int)

fun dataClassCopy() {
    val bob = Client4("Bob", 973293)
	val bob1 = bob.copy(postalCode = 382555)
    println(bob1)
}

//_________________________________________________________

interface Superpower {
	fun fly()
	fun saveWorld()
}

class Superman: Superpower {
	override fun fly() 		 { println("Fly Like Superman!") }
	override fun saveWorld() { println("SaveWorld Like Superman!") }	
}

class Heman : Superpower {
	override fun fly() 		 { println("Fly Like Heman!") }
	override fun saveWorld() { println("SaveWorld Like Heman!") }	
}

class Human {
	var power: Superpower ? = null 
	fun fly() 		 { power?.fly() } 
	fun saveWorld()  { power?.saveWorld() } 
}

class HumanNew(power: Superpower) : Superpower by power {
	// var power: Superpower ? = null 
	// fun fly() 		 { power?.fly() } 
	// fun saveWorld()  { power?.saveWorld() } 
}

fun playWithHuman() {
	val h = Human()
	h.fly()
	h.saveWorld()

	h.power = Superman()
	h.fly()
	h.saveWorld()

	h.power = Heman()
	h.fly()
	h.saveWorld()

	println("Human New....")
	val hn = HumanNew(Superman())
	hn.fly()
	hn.saveWorld()
}

//_________________________________________________________
fun main() {
	println("\nFunction : playWithButton")
	playWithButton()

	println("\nFunction : playWithButtonn")
	playWithButtonn()

	println("\nFunction : playWithSome")
	playWithSome()

	println("\nFunction : playWithIntefacesAndClasses")
	playWithIntefacesAndClasses()

	println("\nFunction : stringRepresentationToString")
	stringRepresentationToString()

	println("\nFunction : objectEqualityEquals")
	objectEqualityEquals()

	println("\nFunction : objectEqualityEquals1")
	objectEqualityEquals1()

	println("\nFunction : dataClassCopy")
	dataClassCopy()

	println("\nFunction : playWithHuman")
	playWithHuman()
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

