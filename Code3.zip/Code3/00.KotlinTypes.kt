package learnKotlin

// Type System is Theorem
interface Expr
class Num(val value: Int) : Expr
class Sum(val left: Expr, val right: Expr) : Expr

// Program Is A Proof!
fun eval(e: Expr) : Int {
	if (e is Num) {
		return e.value
	} else if (e is Sum) {
		return eval(e.left) + eval(e.right)
	}

	throw IllegalArgumentException("Unknown Expression!")
}

fun playWithEval() {
	// 10 + 20
	println( eval( Sum( Num(10), Num(20)) ) )
	// (10 + 20) + 30
	println( eval( Sum( Sum( Num(10), Num(20) ), Num(100) ) ) )
}


fun evalIf(e: Expr) = 
	if (e is Num) {
			e.value
		} else if (e is Sum) {
			eval(e.left) + eval(e.right)
		} else {
			throw IllegalArgumentException("Unknown Expression!")
}

fun evalWhen(e: Expr) = when (e) {
		is Num 	-> e.value
		is Sum -> eval(e.left) + eval(e.right)
		else 	-> throw IllegalArgumentException("Unknown Expression!")
}

fun main() {
	println("\nFunction: playWithEval")
	playWithEval()

	// println("\n Function: ")
	// println("\n Function: ")
	// println("\n Function: ")
	// println("\n Function: ")
	// println("\n Function: ")
	// println("\n Function: ")
	// println("\n Function: ")
	// println("\n Function: ")
}
