
#include <stdio.h>

typedef struct person_type {
	int id;
	char name[100];
} Person;

void playWithPerson() {
	Person person = { 10, "Ram Singh" };

	printf("\nPerson ID: %d Name: %s", 
		person.id, person.name);
}

int main() {
	playWithPerson();
}
