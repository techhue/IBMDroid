package learnKotlin

fun sum(a: Int, b: Int) : Int = a + b
fun sub(a: Int, b: Int) : Int = a - b

fun calculator(a: Int, b: Int, operation: (Int, Int) -> Int) : Int {
	return operation(a, b)
}

fun playWithCalculator() {
	val a = 10
	val b = 20
	println(calculator(a, b, ::sum))
	println(calculator(a, b, ::sub))
}

fun playWithFunctionType() {
	val a = 10
	val b = 20

	val something1 = ::sum
	val something2: (Int, Int) -> Int = ::sum
	println(something1(a, b))
	println(something2(a, b))

	val somethingMore: (Int, Int, (Int, Int) -> Int) -> Int = ::calculator
	println(somethingMore(a, b, something1) )

	//fun sum(a: Int, b: Int) : Int = a + b
	val add = { x: Int, y: Int -> x + y } // Lambda Expression
	println( calculator(a, b, add) )
}

fun playWithLambdas() { 
	val a = 10
	val b = 20

	val add = { x: Int, y: Int -> x + y } // Lambda Expression
	println( add(a, b) )

	val sub = { x: Int, y: Int -> x - y } // Lambda Expression
	println( sub(a, b) )

	// val something = {  println("Hello World!") }
	// something()
	// { println(42) }()
}

class Person(val name: String, val age: Int)
fun playWithLambdas1() { 
	val people = listOf(Person("Ram", 30), Person("Shyam", 20), Person("Ding", 19))

	val names = people.joinToString(separator = " ", transform = { person: Person -> person.name } )
	println(names)

	val something1 = { person: Person -> person.name }
	val names1 = people.joinToString(separator = " ", transform =  something1)
	println(names1)

	val something2 = { person: Person -> person.age }
	// val names2 = people.joinToString(separator = " ", transform =  something2)
	// println(names2)

}

fun main() {
	println("\nFunction : playWithCalculator")
	playWithCalculator()
	
	println("\nFunction : playWithFunctionType")
	playWithFunctionType()

	println("\nFunction : playWithLambdas")
	playWithLambdas()

	println("\nFunction : playWithLambdas1")
	playWithLambdas1()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}