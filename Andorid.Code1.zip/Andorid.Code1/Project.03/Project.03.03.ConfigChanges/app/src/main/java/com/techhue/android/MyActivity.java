package com.techhue.android;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;

public class MyActivity extends Activity {
    /**
     * Called when the activity is first created.
     */
    private static String TAG = "com.techhue.configuration_changes.MyActivity";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("MyStateChangeActivity", "onPause");
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d("MyStateChangeActivity", "onStop");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("MyStateChangeActivity", "onDestroy");
    }

    /**
     * Listing 3-6: Handling configuration changes in code
     */
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        Log.d(TAG, "onConfigurationChanged");
        // [ ... Update any UI based on resource values ... ]

        if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            // [ ... React to different orientation ... ]\
            Log.d(TAG, "Orientation Landscape");
        } else if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            // [ ... React to different orientation ... ]\
            Log.d(TAG, "Orientation Landscape");
        }

        if (newConfig.keyboardHidden == Configuration.KEYBOARDHIDDEN_NO) {
            // [ ... React to changed keyboard visibility ... ]
            Log.d(TAG, "Keyboard Hidden No");
        }
    }
}