package learnKotlin

// Theorem
interface Capability

// interface Superpower {
// 	fun fly()
// 	fun saveWorld()
// }

interface Superpower: Capability {
	fun fly()
	fun saveWorld()
}

interface Dancing: Capability {
	fun dance()
}

interface Singing: Capability {
	fun sing()
}

class Spiderman: Superpower, Dancing {
	override fun fly() 		 { println("Fly Like Spiderman!") }
	override fun saveWorld() { println("SaveWorld Like Spiderman!") }	
	override fun dance() 	 { println("Dance Like Spiderman!") }	
}

class Superman: Superpower {
	override fun fly() 		 { println("Fly Like Superman!") }
	override fun saveWorld() { println("SaveWorld Like Superman!") }	
}

class Heman : Superpower {
	override fun fly() 		 { println("Fly Like Heman!") }
	override fun saveWorld() { println("SaveWorld Like Heman!") }	
}

class HanumanJi : Superpower {
	override fun fly() 		 { println("Fly Like HanumanJi!") }
	override fun saveWorld() { println("SaveWorld Like HanumanJi!") }	
}

class Human {
	var power: Superpower? = null // New Thing
	// var dancing: Dancing? = null
	fun fly() 		 { power?.fly() } // super.fly() }
	fun saveWorld()  { power?.saveWorld() } // super.saveWorld }
	fun dance()		 { 
		val buddy = power as Dancing
		buddy.dance() 
	}
}

// Proof!
fun playWithHuman() {
	val h = Human()
	h.power = Spiderman()
	// h.dancing =  Spiderman()
	h.fly()
	h.saveWorld()
	h.dance()

	h.power = Superman()
	h.fly()
	h.saveWorld()

	// h.power = Heman()
	// h.fly()
	// h.saveWorld()

	// h.power = HanumanJi()
	// h.fly()
	// h.saveWorld()
}

class InterestingHuman {
	var capability: Capability ? = null 
	
	fun fly() 		 { 
		if // Type Check Then
		val buddy = capability as Superpower
		buddy.fly() 
	} 

	fun saveWorld()  { 
		val buddy = capability as Superpower
		buddy.saveWorld() 
	} 
	
	fun dance()		 { 
		val buddy = capability as Dancing
		buddy.dance() 
	}
}


fun main() {
	playWithHuman()
}