package learnKotlin

// Type System is Theorem
interface Expr
class Num(val value: Int) : Expr
class Sum(val left: Expr, val right: Expr) : Expr

// Program Is A Proof!
fun eval(e: Expr) : Int {
	if (e is Num) {
		return e.value
	} else if (e is Sum) {
		return eval(e.left) + eval(e.right)
	}

	throw IllegalArgumentException("Unknown Expression!")
}

fun playWithEval() {
	// 10 + 20
	println( eval( Sum( Num(10), Num(20)) ) )
	// (10 + 20) + 30
	println( eval( Sum( Sum( Num(10), Num(20) ), Num(100) ) ) )
}


fun evalIf(e: Expr) = 
	if (e is Num) {
			e.value
		} else if (e is Sum) {
			eval(e.left) + eval(e.right)
		} else {
			throw IllegalArgumentException("Unknown Expression!")
}

fun evalWhen(e: Expr) = when (e) {
		is Num 	-> e.value
		is Sum -> eval(e.left) + eval(e.right)
		else 	-> throw IllegalArgumentException("Unknown Expression!")
}

fun playWithNullability() {
	var something: String? = "Ding Dong"
	var length = something?.length
	var length2 = something!!.length
	println(length)
	println(length2)

	something = null
	
	// val value = if (something != null ) something else null

	length = something?.length 
	// Compiler Generate Codes
	// if (something) something.length else null
	println(length)
	
	val length1 = something?.length ?: 0
	// Compiler Generate Codes
	// if (something) something.length else o
	println(length1)
	
	// length2 = something!!.length 
	// Compiler Generate Codes
	// something.length
	println(length2)
}

class Address(val streetAddress: String, val zipCode: Int,
              val city: String, val country: String)
class Company(val name: String, val address: Address?)
class Person(val name: String, val company: Company?)

fun Person.countryName(): String {
   // val country = this.company?.address?.country
   // return if (country != null) country else "Unknown"

	// Elvis Operator ?:
    val country = this.company?.address?.country ?: "Unknown"
	return country
}

fun safeCallOperator2() {
    val person = Person("Dmitry", null)
    println(person.countryName())
}

fun main() {
	println("\nFunction: playWithEval")
	playWithEval()

	println("\n Function: playWithNullability")
	playWithNullability()

	// println("\n Function: ")
	// println("\n Function: ")
	// println("\n Function: ")
	// println("\n Function: ")
	// println("\n Function: ")
	// println("\n Function: ")
	// println("\n Function: ")
}
