
Android Tool Chain
____________________________________________________	
	https://developer.android.com/studio

	Download Android Studio
		android-studio-ide-192.6241897-windows.zip
		Size 752 MB4
	Unzip 
	Run Android Studio: 
		android-studio > bin
			Run studio64.exe

TestApp Project Window
____________________________________________________
	Tools > Android SDK Manager
		SDK Platform
			Android SDK Platform 28
			Sources For Android 28
			Intel x86 Atom_64 System Image

		SDK Tools
			Android SDK Build Tool Version > 28.0.3

Download Code Samples
____________________________________________________
1. Android.Code1.zip and Unzip It

Android Studio 
	File > Open 	
		Android.Code1 > Project.03 > ... 
			Project.03.01.ManifestAndResources
			Project.03.02.Snippets
			Project.03.03.ConfigChanges
			Project.03.04.Activities

Do Following Changes In Sample Code
____________________________________________________
	gradle > wrapper > gradle-wrapper.properties
		gradle-5.6.4-all.zip

	Project Level [e.g. TestApp]
		Modify build.gradle
			classpath 'com.android.tools.build:gradle:3.6.1'

	Module Level [e.g. app]
		Modify build.gradle
			compileSdkVersion 28
			buildToolsVersion "28.0.3"
			minSdkVersion 23
	        targetSdkVersion 28

	Click Gradle Sync - To Apply Your Changes In The Project
	Run Project In AVD
____________________________________________________


Training Conventions!
____________________________________________________
	Discuss Among Yourself!
		Let Me Know Which Way You Want Training?
		Giving You 10 Minutes
		I will Ask You After 10 Minutes

Training Duration!
____________________________________________________
	15 Days = 10 Days + 5 Days [ Shadow Project]
 	15 Days = 11 Days + 4 Days [ Shadow Project] 
 					  + 2 Days [ Saturday/Sunday ]
 	10 Days Project Works!

Training Pedagogy!
____________________________________________________
	Trainer 
		- Focus On Design Thinking!
		- Sound Reasoning!

	Participants 
		- Programming/Coding 
		- Reading Tutorials

GitHub Repository and Learning Progression
____________________________________________________
	https://github.com/techhue/IBMDroid
	https://tinyurl.com/ruok4ne

Installing Kotlin Compiler
____________________________________________________
	- Download kotlin-compiler-1.3.61.zip
	- Unzip In IBMDroid Directory

Running Kotlin Compiler
____________________________________________________
	cd kotlinc/bin
	./kotlinc

Configure PATH Variable
____________________________________________________
	Add Following Path in PATH Variable
		YOUR_DIRECTORY\Documents\IBMDroid\kotlinc\bin
	
	Invoke Kotlin Compiler
		Now You Can Invoke Following Command From Any Path
		
		kotlinc

Install Java SDK 1.8
____________________________________________________
	https://www.oracle.com/java/technologies/javase/javase-jdk8-downloads.html

	Java JDK 1.8 - For Windows 64 Bit Architecture
	________________________________________________
	Download : jdk-8u241-windows-x64.exe
		Size : 210.92 MB	
	Install  : jdk-8u241-windows-x64.exe

DAY 1
____________________________________________________
	Reading Assignments
	________________________________________________
		Data Type and Control Structures Chapters

		Programming In C By Kernigham and Dennis Ritchie
		2nd Edition

	Reasoning Assignments
	________________________________________________
		Is it possible to have variable
			Without Type as an Idea?

		Is it possible to have value 
			Without Type as an Idea?

		Which is Most Fundamental Value/Variable/Type
			Reason It!
DAY 2
____________________________________________________
	Reading Assignments
	________________________________________________
		Programming In C By Kernigham and Dennis Ritchie
		2nd Edition

		Data Type and Control Structures Chapters
		Function Chapter
		
	Reasoning Assignments
	________________________________________________
		Which is Most Fundamental Value/Variable/Type
			Reason It!
		
		Type and Variables/Value Must Coexits Always!
			Reason It?

		Set Definition:
			Collection of Objects. 
			Order and Duplicates Doesn't Matters

			What is an Object?
			Why Order Doesn't Matters?
				What Is Far More Fundamental 
					Order or Unordered?
				Reason It!
			Why Duplicates Doesn't Matters?

DAY 3
____________________________________________________
	Reading Assignments
	________________________________________________
		Java Collections - Cay Hortsman

		Programming In C By Kernigham and Dennis Ritchie
		2nd Edition
			Array and Pointers Chapter [MUST]

DAY 4
____________________________________________________
	Reading Assignments
	________________________________________________
		Java Collections - Cay Hortsman

		Programming In C By Kernigham and Dennis Ritchie
		2nd Edition
			Array and Pointers Chapter [MUST]

		Type Check In Java
	
	Reasoning Assignments
	________________________________________________
		Is Class Fundamental?
			Reason It!

		Why James Josling Said, " I will remove class idea itself"

DAY 5
____________________________________________________
	Read and Coding Assignments
	________________________________________________
		What Are Singleton Classes In Java/C++?
		How to create Singleton Classes?
			In Java/C++
		
	Reasoning Assignments
	________________________________________________
		When you say System Evolution is Evolution!
			Not Just a Change!
			Change For Better!

DAY 6
____________________________________________________
	Read and Coding Assignments
	________________________________________________
		Programming In C By Kernigham and Dennis Ritchie
		2nd Edition
			Array and Pointers Chapter [MUST]

			Write Code To Proov
				Correspondance Between Arrays And Pointers

	Coding Assignments
	________________________________________________
		- Revisit Kotlin Code Again
		- Create Singleton Class Assignments
				Java/C++
DAY 7
____________________________________________________
	Reading Assignments
	________________________________________________
		Kotlin In Action, Dmitry Jemerov and Svetlana Isakova
		First 8 Chapters READ THROUGHLY
		
	Coding Assignments [MUST]
	________________________________________________
		- Practice Kotlin Code

DAY 8
____________________________________________________
	Reading Assignments
	________________________________________________
		Static Members in C/C++/Java
			Meaning and Purpose Of It
	
	Coding Assignments [MUST]
	________________________________________________
		- Practice Kotlin Code

DAY 9
____________________________________________________
	Coding Assignments [MUST]
	________________________________________________
	Write Kotlin Code For Following Code Examples
		Android.Code1 > Project.03 > ... 
			Project.03.01.ManifestAndResources
			Project.03.02.Snippets
			Project.03.03.ConfigChanges
			Project.03.04.Activities
DAY 10
____________________________________________________


Data Type
____________________________________________________
	Type is { Operations, Range }
	
	Type Analysis
		Deeper Type Analysis
			Depth Wise Type Analysis

	Type Inferencing
		Explicit In C/C++
		Implicit In Kotlin
		
	Type Binding
		Compile Time
			C/C++/Java/Kotlin
		Run Time
			Python/Ruby/javase

	Type Safety


Thinking Exercise
____________________________________________________
