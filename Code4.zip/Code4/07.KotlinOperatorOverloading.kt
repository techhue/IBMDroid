
package learnKotlin

data class Vector(var x: Float, var y: Float) {
	operator fun plus(other: Vector): Vector {
		return Vector(x + other.x, y + other.y )
	}
}

fun playWithVector() { 
	val vector1 = Vector(10.0F, 20.0F)
	val vector2 = Vector(100.0F, 200.0F)
	val vector3 = Vector(10.0F, 20.0F)
	
	println ( vector1 == vector2 )
	// Compiler Will Generate
	// vector1.equal(vector2)

	println ( vector1 == vector3 )
	// Compiler Will Generate
	// vector1.equal(vector3)

	val vector4 = vector1 + vector2
	// Compiler Will Generate
	// vector1.plus(vector2)

	println(vector1)
	println(vector2)
	println(vector4)
}

data class Point(val x: Float, val y: Float)
operator fun Point.plus(other: Point): Point {
		return Point(x + other.x, y + other.y )
}

operator fun Char.times(count: Int): String {
    return toString().repeat(count)
}

fun playWithCharTimesExtension() {
    println('a' * 3)
}

operator fun Vector.get(index: Int): Float {
    return when(index) {
        0 -> x
        1 -> y
        else ->
            throw IndexOutOfBoundsException("Invalid coordinate $index")
    }
}

operator fun Vector.set(index: Int, value: Float) {
    when(index) {
        0 -> x = value
        1 -> y = value
        else ->
            throw IndexOutOfBoundsException("Invalid coordinate $index")
    }
}

fun playWithVectorIndex() {
    val vector = Vector(10.0F, 20.0F)
    println(vector[0])
    println(vector[1])

    println(vector)    
    vector[0] = 88F
    vector[1] = 99F
    println(vector)    
}

data class Point8(val x: Int, val y: Int)
data class Rectangle(val upperLeft: Point8, val lowerRight: Point8)

operator fun Rectangle.contains(p: Point8): Boolean {
    return p.x in upperLeft.x until lowerRight.x &&
           p.y in upperLeft.y until lowerRight.y
}

fun operatorIn() {
    val rect = Rectangle(Point8(10, 20), Point8(50, 50))
    println(Point8(20, 30) in rect)
    println(Point8(5, 5) in rect)
}

fun main() {
	println("\nFunction : playWithVector")
	playWithVector()

	println("\nFunction : playWithCharTimesExtension")
	playWithCharTimesExtension()

	println("\nFunction : playWithVectorIndex")
	playWithVectorIndex()

	println("\nFunction : operatorIn ")
	operatorIn()
	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}