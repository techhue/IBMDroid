package learnKotlin

/*
In Directory: IBMDroid\Code
File Name	: Hello.kt

Run Following Commands
	kotlinc Hello.kt -include-runtime -d hello.jar
	java -jar hello.jar
*/

fun main() {
	val hello = "Hello World!"
	println(hello)	
}
