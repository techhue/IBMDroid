#include <stdio.h>
typedef struct person_type {
	int id;
	char name[100];
	void **VPTR = &functions; // Mechanism To Map Message To Methods 
} Person;

// Mapping Table - Messages To Methods
void *functions[2] = {
	void (*dance)();
	void (*sing)();
}

void doBhangra()       	{  printf("\n Balleeee Baleeeee...");  }
void doBharatNatayam() 	{  printf("\n Moving Eyes...");	}
void popMusic() 	{ printf("\n Sing Pop Music");	}
void classicalMusic() 	{ printf("\n Sing Classicall Music");	}

void playWithPerson() {
	// person is an Object of Person Type
	Person person = { 10, "Ram Singh", doBhangra, classicalMusic };
	printf("\nPerson ID: %d Name: %s", 
		person.id, person.name);
	
	person.dance();
	person.dance = doBharatNatayam;
	person.dance();
	person.sing();
}

int main() {
	playWithPerson();
}
