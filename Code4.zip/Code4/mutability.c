#include <stdio.h>

void playWithMutability() {
	int a = 20;
	const int b = 30;
	const int *aptr = &a;
	const int *bptr = &b;

	const int const  *aaptr = &a;
	int const *bbptr = &b;
	const int const *ccptr1 = &b;
	const int * const ccptr2 = &b;
}


int main() {
	playWithMutability();
}
