package learnKotlin

fun sum(a: Int, b: Int) : Int = a + b
val add = { x: Int, y: Int -> x + y } // Lambda Expression

fun sub(a: Int, b: Int) : Int = a - b

// Invariant
fun calculator(a: Int, b: Int, operation: (Int, Int) -> Int) : Int {
	return operation(a, b)
}

fun playWithCalculator() {
	val a = 10
	val b = 20
	println(calculator(a, b, ::sum)) // ::sum is Function Reference
	println(calculator(a, b, { x: Int, y: Int -> x + y } ) )
	println(calculator(a, b, ::sub))
}

fun playWithFunctionType() {
	val a = 10
	val b = 20

	val something1 = ::sum
	val something2: (Int, Int) -> Int = ::sum
	println(something1(a, b))
	println(something2(a, b))

	val somethingMore: (Int, Int, (Int, Int) -> Int) -> Int = ::calculator
	println(somethingMore(a, b, something1) )

	//fun sum(a: Int, b: Int) : Int = a + b
	val add = { x: Int, y: Int -> x + y } // Lambda Expression
	println( calculator(a, b, add) )
}

fun playWithLambdas() { 
	val a = 10
	val b = 20

	val add = { x: Int, y: Int -> x + y } // Lambda Expression
	println( add(a, b) )

	val sub = { x: Int, y: Int -> x - y } // Lambda Expression
	println( sub(a, b) )

	val add3 = { x: Int, y: Int, z: Int -> x + y + z } // Lambda Expression
	println( add3(a, b, 90) )

	// val something = {  println("Hello World!") }
	// something()
	// { println(42) }()
}

class Person(val name: String, val age: Int)
fun playWithLambdas1() { 
	val people = listOf(Person("Ram", 30), Person("Shyam", 20), Person("Ding", 19))

	val names = people.joinToString(separator = " ", transform = { person: Person -> person.name } )
	println(names)

	val something1 = { person: Person -> person.name }
	val names1 = people.joinToString(separator = " ", transform =  something1)
	println(names1)

	// val something2 = { person: Person -> person.age }
	// val names2 = people.joinToString(separator = " ", transform =  something2)
	// println(names2)

}

var some = 100

// Closure/Lambda
// It's Context Which Captures Enclosing Context
fun doSomething() {
	val something = 10
	print ( some + something )
	sum(1000, 9000)
}

data class Person1(val name: String, val age: Int, val marks: Int)
fun findTheOldest(people: List<Person1>) {
    // var maxAge = 0
    // var theOldest: Person1? = null
    var maxMarks = 0
    var maxPerson: Person1? = null
    for (person in people) {
        // if (person.age > maxAge) {
        if (person.age > maxMarks) {
        	// maxAge = person.age
         //    theOldest = person

        	maxMarks = person.marks
            maxPerson = person
        }
    }
   	// println(theOldest)
    println(maxPerson)
}

fun playWithTheOldest() {
    val people = listOf(Person1("Alice", 29, 10), 
    				Person1("Bob", 31, 100),
    				Person1("Ding", 31, 90),
    				Person1("Dong", 31, 70)
    				)
    findTheOldest(people)
}

fun findMax1(people: List<Person1>, criteria: Int ) {
    var maxValue = 0
    var maxPerson: Person1? = null
    for (person in people) {
        // if (person.age > maxAge) {
        if ( criteria > maxValue ) {
            maxValue = criteria
            maxPerson = person
        }
    }
    // return  (maxPerson, maxValue)
    println(maxPerson)
    println(maxValue)
}

fun playWithFindMax1() {
    val people = listOf(Person1("Alice", 29, 10), 
    				Person1("Bob", 31, 100),
    				Person1("Ding", 11, 90),
    				Person1("Dong", 19, 70)
    				)

    val person = people.get(0)
    findMax1(people, person.age)
	findMax1(people, person.marks)
}

enum class SELECT { Age, Marks}
fun findMax2(people: List<Person1>, criteria: SELECT ) {
    var maxValue = 0
    var maxPerson: Person1? = null
    var compareValue = 0

    for (person in people) {
    	if (criteria == SELECT.Age )
    		compareValue = person.age
    	else if (criteria == SELECT.Marks )
    		compareValue = person.marks
        // if (person.age > maxAge) {
        if ( compareValue > maxValue ) {
            maxValue = compareValue
            maxPerson = person
        }
    }
    // return  (maxPerson, maxValue)
    println(maxPerson)
    println(maxValue)
}

fun playWithFindMax2() {
    val people = listOf(Person1("Alice", 29, 10), 
    				Person1("Bob", 11, 100),
    				Person1("Ding", 31, 90),
    				Person1("Dong", 19, 70)
    				)

    // val person = people.get(0)
    findMax2(people, SELECT.Age)
	findMax2(people, SELECT.Marks)
}

fun selectValues(value1: Int, value2: Int): Boolean {
	return value1 > value2 
}

// Invariant 
fun findMax3(people: List<Person1>, choose: (Int, Int) -> Boolean ) {
    var maxValue = 0
    var maxPerson: Person1? = null
    var compareValue = 0

    for (person in people) {
    	// if (person.age > maxAge) {
        // if ( Lambda ) {
    	compareValue = person.age
        if ( choose(person.age, maxValue) ) {
            maxValue = compareValue
            maxPerson = person
        }
    }
    // return  (maxPerson, maxValue)
    println(maxPerson)
    println(maxValue)
}

fun playWithFindMax3() {
    val people = listOf(Person1("Alice", 29, 10), 
    				Person1("Bob", 11, 100),
    				Person1("Ding", 31, 90),
    				Person1("Dong", 19, 70)
    				)

    // val person = people.get(0)
    findMax3(people, ::selectValues)
	findMax3(people, ::selectValues)
}

fun lambdaExpressions3() {
    val people = listOf(Person("Alice", 29), Person("Bob", 31))

    val names = people.joinToString(separator = " ",
                          transform = { p: Person -> p.name })
    println(names)
}


// Algorithm Invariant
fun find(people: List<Person1>, 
	transform: (Person1) -> Int,
	choice: (Int, Int) -> Boolean ) {

    var maxValue = 0
    var maxPerson: Person1? = null
    var compareValue = 0
    for (person in people) {
    	compareValue = transform(person)
        if ( choice(compareValue, maxValue) ) {
            maxValue = compareValue
            maxPerson = person
        }
    }
    println(maxPerson)
    println(maxValue)
}

fun playWithFindMax4() {
    val people = listOf(Person1("Alice", 29, 10), 
    				Person1("Bob", 11, 100),
    				Person1("Ding", 31, 90),
    				Person1("Dong", 19, 70),
    				Person1("Dong", 19, -70)
    				)
    find(people, { p: Person1 -> p.age }, 
    	{v1: Int, v2: Int -> v1 > v2 } )
	find(people, { p: Person1 -> p.marks }, 
		{v1: Int, v2: Int -> v1 < v2 } )
}


fun printMessagesWithPrefix(messages: Collection<String>, 
							prefix: String) {
    messages.forEach { // Trailing Lambdas
        println("$prefix $it")
    }
}

fun accessingVariablesInScope() {
    val errors = listOf("403 Forbidden", "404 Not Found")
    printMessagesWithPrefix(errors, "Error:")
}

fun printProblemCounts(responses: Collection<String>) {
    var clientErrors = 0
    var serverErrors = 0
    responses.forEach {
        if (it.startsWith("4")) {
            clientErrors++
        } else if (it.startsWith("5")) {
            serverErrors++
        }
    }
    println("$clientErrors client errors, $serverErrors server errors")
}

fun accessingVariablesInScope1() {
    val responses = listOf("200 OK", "418 I'm a teapot",
                           "500 Internal Server Error")
    printProblemCounts(responses)
}

fun salute() = println("Salute!")

fun memberReferences() {
	salute()
    run(::salute)
}


fun memberReferences1() {
    val createPerson = ::Person
    val p = createPerson("Alice", 29)
    println(p)
}

fun filterMap() {
    val list = listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    println(list.filter { it % 2 == 0 })
    println(list.filter { it % 2 == 0 }.map { it -> it * it } )
	
	println(list.map { it -> it * it }.filter { it % 2 == 0 } )
}

fun filterMap1() {
    val people = listOf(Person("Alice", 29), Person("Bob", 31))
    println(people.filter { it.age > 30 })
    println(people.map { it.name })
}

val canBeInClub27 = { p: Person -> p.age <= 27 }

fun allAnyCountFind() {
    val people = listOf(Person("Alice", 27), Person("Bob", 31))
    println(people.all(canBeInClub27))
}

fun allAnyCountFind1() {
    val list = listOf(1, 2, 3)

    println(!list.all { it == 3 })
    println(list.any { it != 3 })
}

fun allAnyCountFind2() {
    val people = listOf(Person("Alice", 27), Person("Bob", 31))
    println(people.find(canBeInClub27))
}

data class Person(val name: String, val age: Int)

fun groupBy() {
    val people = listOf(Person("Alice", 31),
            Person("Bob", 29), Person("Carol", 31))
    println(people.groupBy { it.age })
}

fun executingSequenceOperations() {
    listOf(1, 2, 3, 4).asSequence()
            .map { print("map($it) "); it * it }
            .filter { print("filter($it) "); it % 2 == 0 }
}

fun executingSequenceOperations1() {
    listOf(1, 2, 3, 4).asSequence()
            .map { print("map($it) "); it * it }
            .filter { print("filter($it) "); it % 2 == 0 }
            .toList()
}

fun main() {
	println("\nFunction : playWithCalculator")
	playWithCalculator()
	
	println("\nFunction : playWithFunctionType")
	playWithFunctionType()

	println("\nFunction : playWithLambdas")
	playWithLambdas()

	println("\nFunction : playWithLambdas1")
	playWithLambdas1()

	println("\nFunction : doSomething")
	doSomething()

	println("\nFunction : playWithTheOldest")
	playWithTheOldest()

	println("\nFunction : playWithFindMax1")
	playWithFindMax1()

	println("\nFunction : playWithFindMax2")
	playWithFindMax2()
	
	println("\nFunction : playWithFindMax4")
	playWithFindMax4()

	println("\nFunction : accessingVariablesInScope")
	accessingVariablesInScope()

	println("\nFunction : accessingVariablesInScope1")
	accessingVariablesInScope1()

	println("\nFunction : filterMap")
	filterMap()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}