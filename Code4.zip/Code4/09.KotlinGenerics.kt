package learnKotlin

// What it is?
// Push/Pop

interface Stackable {
	fun push(item: Int) 
	fun pop(): Int
}

interface System {
	fun isEmpty(): Boolean 
}

interface Finite: System {
	fun isFull() : Boolean
}

class StackInt : Stackable {
	var items = ArrayList<Int>()

	override fun push(item: Int) { 
		items.add(0, item)	
	}
	
	override fun pop(): Int? {
		if (items.size > 0)  
			return items.removeAt(0)
		else return null
			// throw Exception("Stack Is Empty!")
			// return items.size
	}	
}

class FiniteStackInt : Finite, Stackable {
	var items = ArrayList<Int>()
	var maxSize = 10

	override fun isEmpty(): Boolean {
		return items.size < maxSize 
	}

	override fun isFull(): Boolean {
		return items.size > 0  
	}

	override fun push(item: Int): Int? {
		if (isEmpty()) 
		 	items.add(0, item)
		 	item
		else null
	}
	
	override fun pop(): Int? {
		if (isFull())  
			return items.removeAt(0)
		else return null
			// throw Exception("Stack Is Empty!")
			// return items.size
	}	
}

class FiniteStackString : Finite, Stackable {
	var items = ArrayList<String>()
	var maxSize = 10

	override fun isEmpty(): Boolean {
		return items.size < maxSize 
	}

	override fun isFull(): Boolean {
		return items.size > 0  
	}

	override fun push(item: String): String? {
		if (isEmpty()) 
		 	items.add(0, item)
		 	item
		else null
	}
	
	override fun pop(): String? {
		if (isFull())  
			return items.removeAt(0)
		else return null
			// throw Exception("Stack Is Empty!")
			// return items.size
	}	
}


class <T> FiniteStack<T> : Finite, Stackable {
	var items = ArrayList<T>()
	var maxSize = 10

	override fun isEmpty(): Boolean {
		return items.size < maxSize 
	}

	override fun isFull(): Boolean {
		return items.size > 0  
	}

	override fun push(item: T): T? {
		if (isEmpty()) 
		 	items.add(0, item)
		 	item
		else null
	}
	
	override fun pop(): T? {
		if (isFull())  
			return items.removeAt(0)
		else return null
			// throw Exception("Stack Is Empty!")
			// return items.size
	}	
}

fun playWithStack() {
	val stackInt = StackInt()
	stackInt.push(10)
	stackInt.push(20)
	println(stackInt.pop())
	println(stackInt.pop())
	println(stackInt.pop())

	val stackInt1 = FiniteStack<Int>()
	val stackString = FiniteStack<String>()
}

fun main () {
	playWithStack()
}
