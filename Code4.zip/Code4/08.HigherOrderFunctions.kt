
package learnKotin

// Function Are 1st Class Citizen!
// Higher Order Function
// 		Function Can Take Function Arguments
//		Function Can Return Function
//		Function Can Assigned Value

// Pure Functions: Function Which Doesn't Create SideEffect
// 		Output will Remain Same for Same Inputs
//		(Input, Output) Must Be Invariant

// var something = "Ding Dong"

fun String.filter(predicate: (Char) -> Boolean): String {
    val sb = StringBuilder()
    for (index in 0 until length) {
        val element = get(index)
        if (predicate(element)) sb.append(element)
    }
    // return (sb.toString() + something)
 	return sb.toString()
}

// Church - Turing
fun playWithStringFilter() {
    println("ab1c".filter { it in 'a'..'z' })
    println("ab1cdfkdfj8989aaaabbbb".filter { it in 'a'..'z' })
}

fun <T> Collection<T>.joinToStringDefault(
        separator: String = ", ",
        prefix: String = "",
        postfix: String = "",
        transform: (T) -> String = { it.toString() }
): String {
    val result = StringBuilder(prefix)

    for ((index, element) in this.withIndex()) {
        if (index > 0) result.append(separator)
        result.append(transform(element))
    }
    result.append(postfix)
    return result.toString()
}

fun joinToStringDefaultFunction() {
    val letters = listOf("Alpha", "Beta")

	println(letters.joinToStringDefault())
    println(letters.joinToStringDefault { it.toLowerCase() })
    println(letters.joinToStringDefault(separator = "! ", postfix = "! ",
           transform = { it.toUpperCase() }))
}

fun main() {
	println("\n Function :  playWithStringFilter ")
	playWithStringFilter()

	println("\n Function : joinToStringDefaultFunction")
	joinToStringDefaultFunction()
	// println("\n Function : ")
	// println("\n Function : ")
	// println("\n Function : ")
	// println("\n Function : ")
	// println("\n Function : ")
	// println("\n Function : ")
	// println("\n Function : ")
	// println("\n Function : ")
	// println("\n Function : ")
	// println("\n Function : ")
	// println("\n Function : ")
}