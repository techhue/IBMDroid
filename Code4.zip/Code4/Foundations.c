
#include <stdio.h>
#include <limits.h>

// Good Code
int sumValid(int a, int b) {
  int result = 0;

  // Type Safety
  if (((b > 0) && (a > (INT_MAX - b))) ||
      ((b < 0) && (a < (INT_MIN - b)))) {
    /* Handle error */
 	printf("\n Overflow/Underflow...");
  } else {
  	  // Type Safe Code
  	  result = a + b;
  }
  return result;
}

// Bad Code
int sum(int a, int b) {
	return a + b;
}

void playWithConditionals() {
	int x = -10;
	int y = 0;
	int z = 0;
	
	// return if (x) y++; else y--;

	printf("\nY Value: %d", y);

	z = 10 + ((x)? y++ : y--);
	printf("\nY Value: %d", y);
	printf("\nZ Value: %d", z);
	
	y = (x)? 200 : 300;
	printf("\nY Value: %d", y);
}

enum Color { 
	//0     1    2
	RED, GREEN, BLUE 
};

void playWithColors() {
	enum Color c = RED;
	int something = 10;
	c = something;

	printf("\n Value of Color: %d", c);
	
	enum Color cc = GREEN;
	something = cc;
	printf("\n Value of Color: %d", cc);
	printf("\n Value of Something: %d", something);
}

void playWithTypes() {
	// void v;
}

int sum2(int a, int b) { return a + b; }
int sub2(int a, int b) { return a - b; }

int sum3(int a, int b, int c) { return a + b + c; }

void playWithSum() {
	int (*something)(int, int) = sum2;

	printf("\nSomething Result: %d", something(10, 20));

	// something = sum3;
	something = sub2;
	printf("\nSomething Result: %d", something(10, 20));
}

int main() {
	playWithConditionals();
	playWithColors();
	playWithSum();
}
