package learnKotlin

fun creatingCollectionsInKotlin() {
	val set = hashSetOf(1, 7, 53) 
	val list = arrayListOf(1, 7, 53) 
	val map = hashMapOf(1 to "one", 7 to "seven", 53 to "fifty-three")

    println(set.javaClass)
    println(list.javaClass)
    println(map.javaClass)

    val strings = listOf("first", "second", "fourteenth")
    println(strings.last())
    val numbers = setOf(1, 14, 2)
    println(numbers.max())
}

// Generic Programming -> Write Code To Generate Code
// Generic Types
fun <T> joinToString(
	collection: Collection<T>,
	separator:	String,
	prefix: String,
	postfix: String
): String {
	val result = StringBuilder(prefix)
	// for( element in collection ) {
	// 	println(element)
	// }
	for( (index, element) in collection.withIndex() ) {
		// println("$index : $element")
		if (index > 0) result.append(separator)
		result.append(element)
	}
	result.append(postfix)
	return result.toString()
}

fun playWithJoinToString() {
	val list1 = listOf(1, 2, 3, 4, 5)
	println( joinToString( list1, " : ", "(", ")"))

	val list2 = listOf("Ding", "Dong", "King", "Kong")
	println( joinToString( list2, " : ", "(", ")"))
}

// Compiler Will Generate Following Code For Above Copy
// fun joinToString(
// 	collection: Collection<Int>,
// 	separator:	String,
// 	prefix: String,
// 	postfix: String
// ): String {
// 	// BODY WILL BE SAME AS ABOVE
// }

// fun joinToString(
// 	collection: Collection<String>,
// 	separator:	String,
// 	prefix: String,
// 	postfix: String
// ): String {
// 	// BODY WILL BE SAME AS ABOVE
// }

// Function At File Level
fun lastChar1(s: String): Char = s.get(s.length - 1)

// Extension Function
// Adding Functionality To Existing Type
// New Functionality Will Be Available Everywhere You Use
fun String.lastChar(): Char = this.get(this.length - 1)

fun playWithLastChar() {
	var some = lastChar1("Ding Dong#")
	println("Last Character: $some")

	some = lastChar1("Ping PONG")
	println("Last Character: $some")

	some = "Ding Dong$".lastChar()
	println("Last Character: $some")	
	
	some = "Ping PONGO".lastChar()
	println("Last Character: $some")	
}

// Extention Properties
val String.lastChar: Char
	get() = get(length - 1)

var StringBuilder.lastChar: Char
	get() = get(length - 1)
	set(value: Char) {
		this.setCharAt( length - 1, value)
	}

fun playWithExtensionProperties() {
	println( "SOMETHING".lastChar )

	val someString = StringBuilder("KOLIN?")
	someString.lastChar = '!' //someString.set('!')
	println( someString )
	println( someString.lastChar )
}

fun <T> Collection<T>.joinToStringFinal(
	// collection: Collection<T>,
	separator:	String,
	prefix: String,
	postfix: String
): String {
	val result = StringBuilder(prefix)

	for( (index, element) in this.withIndex() ) {
		// println("$index : $element")
		if (index > 0) result.append(separator)
		result.append(element)
	}
	result.append(postfix)
	return result.toString()
}

fun playWithJoinToStringFinal() {
	val list1 = listOf(1, 2, 3, 4, 5, 6, 7, 8, 9)
	println( list1.joinToStringFinal( " : ", "(", ")"))

	val list2 = listOf("Ding", "Dong", "King", "Kong", "Ting")
	println( list2.joinToStringFinal( " : ", "(", ")"))

	val list3 = arrayListOf(1, 7, 53)
	println( list3.joinToStringFinal( " : ", "(", ")"))
}

fun <T> Collection<T>.joinToStringExtension(
	separator:	String = ", ", // Default Arugments
	prefix: String = "",
	postfix: String = ""
): String {
	val result = StringBuilder(prefix)

	for( (index, element) in this.withIndex() ) {
		if (index > 0) result.append(separator)
		result.append(element)
	}
	result.append(postfix)
	return result.toString()
}

fun playWithJoinToStringExtension() {
	val list1 = listOf(1, 2, 3, 4, 5, 6, 7, 8, 9)
	println( list1.joinToStringExtension() )
	println( list1.joinToStringExtension( " : "))
	println( list1.joinToStringExtension( " : ", "[ "))
	println( list1.joinToStringExtension( " : ", "[ ", " ]"))
}

fun Collection<String>.join(
	separator:	String = "  ", // Default Arugments
	prefix: String = " * ",
	postfix: String = " * "
) = joinToStringExtension(separator, prefix, postfix)

fun playWithJoin() {
	val list2 = listOf("Ding", "Dong", "King", "Kong", "Ting")
	println( list2.join() )
	println( list2.join( " : ", "(", ")"))
}

class User(val id: Int, val name: String, val address: String) 

fun saveUser(user: User) {
	if (user.name.isEmpty()) {
		throw IllegalArgumentException("Supply User Name...")
	}

	if (user.address.isEmpty()) {
		throw IllegalArgumentException("Supply User Address..")
	}

	// SAVE USER DATA...
	println("\tSaving User: ${user.name}")
}

fun playWithSaveUser() {
	val user1 = User(10, "Ram Singh", "Bangalore")
	saveUser(user1)

	// val user2 = User(10, "Sham Singh", "")
	// saveUser(user2)
}

// Nested Function
// Encapsulation -> Localisation

// class
fun saveUser1(user: User) {
	fun validateUser(user: User): Boolean {
		if (user.name.isEmpty()) {
			throw IllegalArgumentException("Supply User Name...")
		}

		if (user.address.isEmpty()) {
			throw IllegalArgumentException("Supply User Address..")
		}
		return true
	}

	validateUser(user)
	// SAVE USER DATA...
	println("\tSaving User: ${user.name}")
}

fun playWithSaveUser1() {
	val user1 = User(10, "Ram Singh", "Bangalore")
	saveUser(user1)
}

fun validateData(user: User) {
	fun validateString(user: User, field: String): Boolean {
		if (field.isEmpty()) {
			throw IllegalArgumentException("Supply Value: ${field}")
		}
		return true
	}

	fun validateID(user: User, field: Int): Boolean {
		if (field <= 0) {
			throw IllegalArgumentException("Supply Value: ${field}")
		}
		return true
	}
}

fun saveUserNested(user: User) {
	fun validateUser(user: User, field: String): Boolean {
		if (field.isEmpty()) {
			throw IllegalArgumentException("Supply Value: ${field}")
		}
		return true
	}

	validateUser(user, user.name)
	validateUser(user, user.address)

	// SAVE USER DATA...
	println("\tSaving User: ${user.name}")
}

fun playWithSaveUser1() {
	val user1 = User(10, "Ram Singh", "Bangalore")
	saveUser(user1)
}

fun User.validateBeforeSave(user: User) {
	fun validateUser(user: User, field: String): Boolean {
		if (field.isEmpty()) {
			throw IllegalArgumentException("Supply Value: ${field}")
		}
		return true
	}

	validateUser(user, user.name)
	validateUser(user, user.address)

	// SAVE USER DATA...
	println("\tSaving User: ${user.name}")
}

fun playWithUser() {
	val user1 = User(10, "Ram Singh", "Bangalore")
	user1.validateBeforeSave(user1)
}


fun main() {
	println("\nFunction : creatingCollectionsInKotlin")
	creatingCollectionsInKotlin();

	println("\nFunction : playWithJoinToString")
	playWithJoinToString()

	println("\nFunction : playWithLastChar")
	playWithLastChar()

	println("\nFunction : playWithJoinToStringFinal")
	playWithJoinToStringFinal()

	println("\nFunction : playWithJoinToStringExtension")
	playWithJoinToStringExtension()

	println("\nFunction : playWithJoin")
	playWithJoin()

	println("\nFunction : playWithExtensionProperties")
	playWithExtensionProperties()

	println("\nFunction : playWithSaveUser")
	playWithSaveUser()

	println("\nFunction : playWithSaveUser1")
	playWithSaveUser1()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}